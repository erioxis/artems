'use strict';

const loadImageBtn = document.getElementById('loadImageBtn');
const addToFavoritesBtn = document.getElementById('addToFavoritesBtn');
const currentImage = document.getElementById('currentImage');
const statusDiv = document.getElementById('statusMessage');
const favoritesGrid = document.getElementById('favoritesGrid');
const radioButtons = document.querySelectorAll('input[name="animalType"]');

const FAVORITES_STORAGE_KEY = 'favoritePets';

let currentImageUrl = null;

// Функция для показа уведомлений
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

function getFormattedDateTime() {
    const now = new Date();
    return now.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

function updateStatus(message, type = 'info') {
    statusDiv.textContent = message;
    statusDiv.className = `status-message ${type}`;
}

function loadAndDisplayFavorites() {
    const favorites = JSON.parse(localStorage.getItem(FAVORITES_STORAGE_KEY)) || [];
    favoritesGrid.innerHTML = '';

    if (favorites.length === 0) {
        const noFavoritesItem = document.createElement('div');
        noFavoritesItem.className = 'no-favorites';
        noFavoritesItem.innerHTML = `
            <div class="no-favorites-icon">📸</div>
            Избранное пусто<br>
            <small>Добавьте понравившиеся изображения</small>
        `;
        favoritesGrid.appendChild(noFavoritesItem);
        return;
    }

    favorites.forEach((item, index) => {
        const favoriteItem = document.createElement('div');
        favoriteItem.className = 'favorite-item';
        favoriteItem.style.animationDelay = `${index * 0.1}s`;

        const img = document.createElement('img');
        img.src = item.url;
        img.alt = `Избранное ${index + 1}`;
        img.className = 'favorite-img';

        const info = document.createElement('div');
        info.className = 'favorite-info';
        info.textContent = item.date;

        const removeBtn = document.createElement('button');
        removeBtn.className = 'remove-favorite';
        removeBtn.innerHTML = '×';
        removeBtn.title = 'Удалить из избранного';
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            showRemoveConfirmation(favorites, index);
        });

        favoriteItem.appendChild(img);
        favoriteItem.appendChild(info);
        favoriteItem.appendChild(removeBtn);

        favoritesGrid.appendChild(favoriteItem);
    });
}

function showRemoveConfirmation(favorites, index) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
    `;
    
    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background: white;
        padding: 30px;
        border-radius: 12px;
        text-align: center;
        max-width: 300px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    `;
    
    modalContent.innerHTML = `
        <div style="font-size: 48px; margin-bottom: 15px;">🗑️</div>
        <h3 style="margin-bottom: 15px; color: #2c3e50;">Удалить из избранного?</h3>
        <p style="color: #666; margin-bottom: 20px; line-height: 1.4;">
            Это изображение будет удалено из вашего избранного.
        </p>
        <div style="display: flex; gap: 10px; justify-content: center;">
            <button id="confirmRemove" style="
                background: #e74c3c;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                cursor: pointer;
                font-weight: 500;
            ">Удалить</button>
            <button id="cancelRemove" style="
                background: #95a5a6;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                cursor: pointer;
                font-weight: 500;
            ">Отмена</button>
        </div>
    `;
    
    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    
    document.getElementById('confirmRemove').addEventListener('click', () => {
        favorites.splice(index, 1);
        localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
        loadAndDisplayFavorites();
        document.body.removeChild(modal);
        showNotification('Изображение удалено из избранного', 'success');
    });
    
    document.getElementById('cancelRemove').addEventListener('click', () => {
        document.body.removeChild(modal);
    });
}

function addToFavorites() {
    if (!currentImageUrl) return;

    const favorites = JSON.parse(localStorage.getItem(FAVORITES_STORAGE_KEY)) || [];
    const newFavorite = {
        url: currentImageUrl,
        date: getFormattedDateTime()
    };

    // Проверяем, нет ли уже такого изображения в избранном
    const isDuplicate = favorites.some(item => item.url === currentImageUrl);
    if (isDuplicate) {
        showNotification('Это изображение уже есть в избранном!', 'error');
        return;
    }

    favorites.unshift(newFavorite);

    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
    loadAndDisplayFavorites();
    updateStatus('Добавлено в избранное!', 'success');
    showNotification('Изображение добавлено в избранное!', 'success');
    
    // Анимация кнопки
    addToFavoritesBtn.innerHTML = '<span>✅</span> Добавлено!';
    setTimeout(() => {
        addToFavoritesBtn.innerHTML = '<span>⭐</span> Добавить в избранное';
    }, 2000);
}

async function loadImage() {
    const selectedAnimal = document.querySelector('input[name="animalType"]:checked').value;
    updateStatus('🔄 Загружается изображение...', 'loading');
    currentImage.classList.remove('loaded');
    currentImage.src = '';
    addToFavoritesBtn.disabled = true;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);

    let apiUrl = '';
    if (selectedAnimal === 'dog') {
        apiUrl = 'https://dog.ceo/api/breeds/image/random';
    } else if (selectedAnimal === 'cat') {
        apiUrl = 'https://api.thecatapi.com/v1/images/search';
    }

    try {
        const response = await fetch(apiUrl, {
            signal: controller.signal
        });

        clearTimeout(timer);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        let data;
        if (selectedAnimal === 'dog') {
            data = await response.json();
            currentImageUrl = data.message;
        } else if (selectedAnimal === 'cat') {
            data = await response.json();
            if (data && data.length > 0 && data[0].url) {
                currentImageUrl = data[0].url;
            } else {
                throw new Error('No image URL found in response');
            }
        }

        if (currentImageUrl) {
            const newImg = new Image();
            newImg.onload = () => {
                currentImage.src = newImg.src;
                currentImage.classList.add('loaded');
                updateStatus('✅ Изображение загружено!', 'success');
                addToFavoritesBtn.disabled = false;
                showNotification('Новое изображение загружено!', 'success');
                
                // Анимация кнопки
                loadImageBtn.innerHTML = '<span>✅</span> Загружено!';
                setTimeout(() => {
                    loadImageBtn.innerHTML = '<span>🔄</span> Загрузить изображение';
                }, 2000);
            };
            newImg.onerror = () => {
                updateStatus('❌ Не удалось загрузить изображение', 'error');
                showNotification('Ошибка загрузки изображения', 'error');
            };
            newImg.src = currentImageUrl;
        } else {
            throw new Error('URL изображения не найден');
        }
    } catch (err) {
        clearTimeout(timer);

        if (err.name === 'AbortError') {
            updateStatus('⏰ Время ожидания истекло', 'error');
            showNotification('Время загрузки истекло', 'error');
        } else {
            console.error("Проблема с fetch:", err);
            updateStatus('❌ Ошибка загрузки', 'error');
            showNotification('Ошибка загрузки изображения', 'error');
        }
        currentImageUrl = null;
        addToFavoritesBtn.disabled = true;
    }
}

// Обработчики событий
loadImageBtn.addEventListener('click', loadImage);
addToFavoritesBtn.addEventListener('click', addToFavorites);

radioButtons.forEach(radio => {
    radio.addEventListener('change', () => {
        currentImage.classList.remove('loaded');
        currentImage.src = '';
        addToFavoritesBtn.disabled = true;
        updateStatus('Выберите животное и загрузите изображение');
    });
});

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Добавляем CSS анимации
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    loadAndDisplayFavorites();
});