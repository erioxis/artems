'use strict';

const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const randomTaskBtn = document.getElementById('randomTaskBtn');
const taskList = document.getElementById('taskList');
const stats = document.getElementById('stats');

const TASKS_STORAGE_KEY = 'todoTasks';

// Функция для показа уведомлений
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

function getFormattedDateTime() {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    return `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
}

function updateStats() {
    const taskCount = document.querySelectorAll('.task-item').length;
    stats.innerHTML = `Всего задач: <strong>${taskCount}</strong>`;
}

function saveTasksToLocalStorage() {
    const tasks = [];
    document.querySelectorAll('.task-item').forEach(item => {
        tasks.push({
            text: item.dataset.taskText,
            date: item.querySelector('.task-header').textContent
        });
    });
    localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
    updateStats();
}

function loadTasksFromLocalStorage() {
    const tasksJSON = localStorage.getItem(TASKS_STORAGE_KEY);
    if (tasksJSON) {
        try {
            const tasks = JSON.parse(tasksJSON);
            taskList.innerHTML = '';
            tasks.forEach(task => {
                const taskElement = createTaskElement(task.text);
                taskElement.querySelector('.task-header').textContent = task.date;
                taskList.appendChild(taskElement);
            });
            updateStats();
        } catch (e) {
            console.error('Ошибка при загрузке задач из localStorage:', e);
            showNotification('Ошибка загрузки сохраненных задач', 'error');
        }
    }
}

function createTaskElement(text) {
    const item = document.createElement('div');
    item.className = 'task-item';
    item.dataset.taskText = text;

    const header = document.createElement('div');
    header.className = 'task-header';
    header.innerHTML = `<span>📅</span> ${getFormattedDateTime()}`;

    const taskText = document.createElement('div');
    taskText.className = 'task-text';
    taskText.textContent = text;

    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'task-buttons';

    const copyBtn = document.createElement('button');
    copyBtn.className = 'task-button copy';
    copyBtn.innerHTML = '<span>📋</span> Копировать';

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'task-button delete';
    deleteBtn.innerHTML = '<span>🗑️</span> Удалить';

    buttonsDiv.appendChild(copyBtn);
    buttonsDiv.appendChild(deleteBtn);

    item.appendChild(header);
    item.appendChild(taskText);
    item.appendChild(buttonsDiv);

    copyBtn.addEventListener('click', () => {
        const taskDiv = copyBtn.closest('.task-item');
        const textToCopy = taskDiv.dataset.taskText;
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(textToCopy)
                .then(() => {
                    const originalText = copyBtn.innerHTML;
                    copyBtn.innerHTML = '<span>✅</span> Скопировано!';
                    showNotification('Текст задачи скопирован в буфер обмена', 'success');
                    setTimeout(() => {
                        copyBtn.innerHTML = originalText;
                    }, 2000);
                })
                .catch(() => {
                    copyUsingExecCommand(textToCopy, copyBtn);
                });
        } else {
            copyUsingExecCommand(textToCopy, copyBtn);
        }
    });

    function copyUsingExecCommand(text, button) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        try {
            if (document.execCommand('copy')) {
                const originalText = button.innerHTML;
                button.innerHTML = '<span>✅</span> Скопировано!';
                showNotification('Текст задачи скопирован', 'success');
                setTimeout(() => {
                    button.innerHTML = originalText;
                }, 2000);
            }
        } catch (e) {
            console.error('Ошибка копирования: ', e);
            showNotification('Ошибка копирования текста', 'error');
        }
        document.body.removeChild(textarea);
    }

    deleteBtn.addEventListener('click', () => {
        item.classList.add('removing');
        setTimeout(() => {
            taskList.removeChild(item);
            saveTasksToLocalStorage();
            if (taskList.children.length === 0) {
                showEmptyMessage();
            }
            showNotification('Задача удалена', 'success');
        }, 300);
    });

    return item;
}

function showEmptyMessage() {
    const emptyMsg = document.createElement('div');
    emptyMsg.className = 'empty-message';
    emptyMsg.innerHTML = `
        <div style="font-size: 48px; margin-bottom: 10px; opacity: 0.5;">📝</div>
        Список задач пуст<br>
        <small>Добавьте первую задачу или используйте случайную</small>
    `;
    taskList.appendChild(emptyMsg);
}

// Обработчики событий
addTaskBtn.addEventListener('click', () => {
    const text = taskInput.value.trim();
    if (text) {
        // Убираем сообщение "список пуст" если оно есть
        const emptyMsg = taskList.querySelector('.empty-message');
        if (emptyMsg) {
            taskList.removeChild(emptyMsg);
        }
        
        const taskElement = createTaskElement(text);
        taskList.insertBefore(taskElement, taskList.firstChild);
        taskInput.value = '';
        saveTasksToLocalStorage();
        showNotification('Задача успешно добавлена!', 'success');
        
        // Анимация кнопки
        addTaskBtn.innerHTML = '<span>✅</span> Добавлено!';
        setTimeout(() => {
            addTaskBtn.innerHTML = '<span>➕</span> Добавить задачу';
        }, 2000);
    } else {
        showNotification('Введите текст задачи', 'error');
    }
});

randomTaskBtn.addEventListener('click', () => {
    if (randomTasks && randomTasks.length > 0) {
        const emptyMsg = taskList.querySelector('.empty-message');
        if (emptyMsg) {
            taskList.removeChild(emptyMsg);
        }
        
        const randomIndex = Math.floor(Math.random() * randomTasks.length);
        const randomTask = randomTasks[randomIndex];
        const taskElement = createTaskElement(randomTask);
        taskList.insertBefore(taskElement, taskList.firstChild);
        saveTasksToLocalStorage();
        showNotification(`Добавлена случайная задача: "${randomTask}"`, 'success');
        
        // Анимация кнопки
        randomTaskBtn.innerHTML = '<span>✅</span> Добавлено!';
        setTimeout(() => {
            randomTaskBtn.innerHTML = '<span>🎲</span> Рандомная задача';
        }, 2000);
    }
});

taskInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        addTaskBtn.click();
    }
});

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Добавляем CSS анимации
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    loadTasksFromLocalStorage();
    updateStats();
});

// Автосохранение при закрытии страницы
window.addEventListener('beforeunload', () => {
    saveTasksToLocalStorage();
});