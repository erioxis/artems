'use strict';

const form = document.getElementById('registrationForm');
const saveBtn = document.getElementById('saveBtn');
const submitBtn = document.getElementById('submitBtn');
const projectParticipationCheckbox = document.getElementById('projectParticipation');
const projectNameGroup = document.getElementById('projectNameGroup');
const projectNameInput = document.getElementById('projectName');
const beforeUnloadModal = document.getElementById('beforeUnloadModal');
const confirmLeaveBtn = document.getElementById('confirmLeaveBtn');
const cancelLeaveBtn = document.getElementById('cancelLeaveBtn');

const FORM_DATA_KEY = 'registrationFormData';

let hasUnsavedChanges = false;

// Функция для показа уведомлений
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Функция для обновления видимости поля названия проекта
function updateProjectNameVisibility() {
    projectNameGroup.style.display = projectParticipationCheckbox.checked ? 'block' : 'none';
    // Не очищаем поле при скрытии, чтобы сохранить данные
}

projectParticipationCheckbox.addEventListener('change', () => {
    updateProjectNameVisibility();
    hasUnsavedChanges = true;
});

form.addEventListener('input', () => {
    hasUnsavedChanges = true;
});

form.addEventListener('change', () => {
    hasUnsavedChanges = true;
});

// Функция для получения данных формы
function getFormData() {
    const gender = document.querySelector('input[name="gender"]:checked');
    
    return {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        middleName: document.getElementById('middleName').value,
        gender: gender ? gender.value : '',
        faculty: document.getElementById('faculty').value,
        projectParticipation: projectParticipationCheckbox.checked,
        projectName: document.getElementById('projectName').value
    };
}

saveBtn.addEventListener('click', () => {
    const data = getFormData();
    
    // Валидация обязательных полей
    if (!data.firstName || !data.lastName || !data.middleName || !data.gender || !data.faculty) {
        showNotification('Пожалуйста, заполните все обязательные поля.', 'error');
        return;
    }

    if (data.projectParticipation && !data.projectName) {
        showNotification('Пожалуйста, укажите наименование проекта.', 'error');
        return;
    }
    
    localStorage.setItem(FORM_DATA_KEY, JSON.stringify(data));
    hasUnsavedChanges = false;
    showNotification('Данные успешно сохранены в localStorage!', 'success');
    
    // Анимация кнопки
    saveBtn.innerHTML = '<span>✅</span> Сохранено!';
    setTimeout(() => {
        saveBtn.innerHTML = '<span>💾</span> Сохранить';
    }, 2000);
});

submitBtn.addEventListener('click', () => {
    const data = getFormData();

    if (!data.firstName || !data.lastName || !data.middleName || !data.gender || !data.faculty) {
        showNotification('Пожалуйста, заполните все обязательные поля.', 'error');
        return;
    }

    if (data.projectParticipation && !data.projectName) {
        showNotification('Пожалуйста, укажите наименование проекта.', 'error');
        return;
    }

    const tableRows = [];
    const fields = [
        { key: 'firstName', label: 'Имя' },
        { key: 'lastName', label: 'Фамилия' },
        { key: 'middleName', label: 'Отчество' },
        { key: 'gender', label: 'Пол', transform: (val) => val === 'male' ? 'Мужской' : 'Женский' },
        { key: 'faculty', label: 'Факультет' },
        { key: 'projectParticipation', label: 'Участие в проекте', transform: (val) => val ? 'Да' : 'Нет' },
        { key: 'projectName', label: 'Наименование проекта' }
    ];

    fields.forEach(field => {
        let value = data[field.key];
        if (field.transform) {
            value = field.transform(value);
        }
        // Показываем все поля, даже пустые
        tableRows.push(`<tr><td>${field.label}</td><td>${value || ''}</td></tr>`);
    });

    const tableHTML = `<table border="1" style="border-collapse: collapse; width: 100%; margin-top: 20px;">
        <thead><tr><th>Наименование поля</th><th>Значение поля</th></tr></thead>
        <tbody>${tableRows.join('')}</tbody>
    </table>`;

    const newWindow = window.open();
    newWindow.document.write(`
        <html>
            <head>
                <title>Результаты формы</title>
                <style>
                    body { 
                        font-family: 'Segoe UI', Arial, sans-serif; 
                        padding: 30px; 
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        min-height: 100vh;
                    }
                    .result-container {
                        background: white;
                        border-radius: 16px;
                        padding: 30px;
                        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
                        max-width: 800px;
                        margin: 0 auto;
                    }
                    h1 { 
                        color: #2c3e50; 
                        text-align: center; 
                        margin-bottom: 30px;
                        font-weight: 500;
                    }
                    table { 
                        margin: 20px auto; 
                        border-collapse: collapse; 
                        width: 100%; 
                        border-radius: 8px;
                        overflow: hidden;
                        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
                    }
                    th, td { 
                        padding: 12px 15px; 
                        border: 1px solid #e0e0e0; 
                        text-align: left; 
                    }
                    th { 
                        background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
                        color: white; 
                        font-weight: 600;
                    }
                    tr:nth-child(even) {
                        background-color: #f8f9fa;
                    }
                    tr:hover {
                        background-color: #e8f4fd;
                    }
                </style>
            </head>
            <body>
                <div class="result-container">
                    <h1>📋 Данные формы регистрации</h1>
                    ${tableHTML}
                </div>
            </body>
        </html>
    `);
    newWindow.document.close();

    hasUnsavedChanges = false;
    showNotification('Форма успешно отправлена!', 'success');
    
    // Анимация кнопки
    submitBtn.innerHTML = '<span>✅</span> Отправлено!';
    setTimeout(() => {
        submitBtn.innerHTML = '<span>📤</span> Отправить';
    }, 2000);
});

confirmLeaveBtn.addEventListener('click', () => {
    beforeUnloadModal.classList.remove('active');
    window.removeEventListener('beforeunload', preventLeave);
    window.location.reload();
});

cancelLeaveBtn.addEventListener('click', () => {
    beforeUnloadModal.classList.remove('active');
});

function preventLeave(e) {
    if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
        beforeUnloadModal.classList.add('active');
        return '';
    }
}

window.addEventListener('beforeunload', preventLeave);

document.addEventListener('DOMContentLoaded', () => {
    // Добавляем CSS анимации
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    const savedData = JSON.parse(localStorage.getItem(FORM_DATA_KEY));
    if (savedData) {
        console.log('Загруженные данные:', savedData); // Для отладки
        
        // Восстанавливаем текстовые поля и селекты
        if (savedData.firstName) document.getElementById('firstName').value = savedData.firstName;
        if (savedData.lastName) document.getElementById('lastName').value = savedData.lastName;
        if (savedData.middleName) document.getElementById('middleName').value = savedData.middleName;
        if (savedData.faculty) document.getElementById('faculty').value = savedData.faculty;
        
        // Восстанавливаем радиокнопки
        if (savedData.gender) {
            const genderRadio = document.querySelector(`input[name="gender"][value="${savedData.gender}"]`);
            if (genderRadio) {
                genderRadio.checked = true;
            }
        }
        
        // Восстанавливаем чекбокс участия в проекте и поле названия проекта
        if (savedData.projectParticipation !== undefined) {
            projectParticipationCheckbox.checked = Boolean(savedData.projectParticipation);
            if (savedData.projectName) {
                document.getElementById('projectName').value = savedData.projectName;
            }
            updateProjectNameVisibility();
        }
        
        hasUnsavedChanges = false;
        showNotification('Данные формы загружены из сохранения', 'success');
    }
});

// Инициализация при загрузке
updateProjectNameVisibility();