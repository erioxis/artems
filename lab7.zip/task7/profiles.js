'use strict';

const profilesGrid = document.getElementById('profilesGrid');
const PROFILE_STORAGE_KEY = 'userProfiles';

function loadAndDisplayProfiles() {
    const profiles = JSON.parse(localStorage.getItem(PROFILE_STORAGE_KEY)) || [];
    profilesGrid.innerHTML = '';

    if (profiles.length === 0) {
        const noProfilesDiv = document.createElement('div');
        noProfilesDiv.className = 'no-profiles';
        noProfilesDiv.textContent = 'Нет сохраненных профилей';
        profilesGrid.appendChild(noProfilesDiv);
        return;
    }

    profiles.forEach((profile, index) => {
        const profileCard = document.createElement('div');
        profileCard.className = 'profile-card';

        const img = document.createElement('img');
        img.src = profile.picture.large;
        img.alt = 'Фото профиля';
        img.className = 'profile-image';

        const infoDiv = document.createElement('div');
        infoDiv.className = 'profile-info';

        const nameP = document.createElement('p');
        nameP.innerHTML = `<strong>Имя:</strong> ${profile.name.title} ${profile.name.first} ${profile.name.last}`;

        const emailP = document.createElement('p');
        emailP.innerHTML = `<strong>Email:</strong> ${profile.email}`;

        const locationP = document.createElement('p');
        locationP.innerHTML = `<strong>Местоположение:</strong> ${profile.location.city}, ${profile.location.country}`;

        const genderP = document.createElement('p');
        genderP.innerHTML = `<strong>Пол:</strong> ${profile.gender === 'male' ? 'Мужской' : 'Женский'}`;

        const savedAtP = document.createElement('p');
        savedAtP.innerHTML = `<strong>Сохранен:</strong> ${profile.savedAt}`;

        infoDiv.appendChild(nameP);
        infoDiv.appendChild(emailP);
        infoDiv.appendChild(locationP);
        infoDiv.appendChild(genderP);
        infoDiv.appendChild(savedAtP);

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'delete-button';
        deleteBtn.textContent = 'Удалить профиль';
        deleteBtn.addEventListener('click', () => {
            profiles.splice(index, 1);
            localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profiles));
            loadAndDisplayProfiles();
            updateProfileCountOnMainPage();
        });

        profileCard.appendChild(img);
        profileCard.appendChild(infoDiv);
        profileCard.appendChild(deleteBtn);

        profilesGrid.appendChild(profileCard);
    });
}

function updateProfileCountOnMainPage() {
    if (window.opener && !window.opener.closed) {
        try {
            window.opener.updateProfileCount && window.opener.updateProfileCount();
        } catch (e) {
            console.warn('Не удалось обновить счетчик на главной странице:', e);
        }
    }
}

document.addEventListener('DOMContentLoaded', loadAndDisplayProfiles);