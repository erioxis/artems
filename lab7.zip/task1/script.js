'use strict';

const loadBtn = document.getElementById('loadCatBtn');
const statusDiv = document.getElementById('statusMessage');
const imgElement = document.getElementById('catImage');
const placeholder = document.getElementById('placeholder');

// Функция для обновления статуса
function updateStatus(message, type = 'info') {
    statusDiv.textContent = message;
    statusDiv.className = `status-message ${type}`;
}

// Функция для показа уведомления
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

async function loadRandomCat() {
    updateStatus('🔄 Загружается милый котик...', 'loading');
    placeholder.style.display = 'none';
    imgElement.style.display = 'block';
    imgElement.classList.remove('loaded');
    loadBtn.disabled = true;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);

    try {
        const response = await fetch('https://api.thecatapi.com/v1/images/search', {
            signal: controller.signal
        });

        clearTimeout(timer);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data && data.length > 0 && data[0].url) {
            // Создаём новый объект Image для проверки загрузки
            const newImg = new Image();
            
            newImg.onload = () => {
                // Передаём данные в основной элемент img
                imgElement.src = newImg.src;
                imgElement.classList.add('loaded');
                updateStatus('✅ Котик успешно загружен!', 'success');
                showNotification('Новый котик загружен! 🐱', 'success');
                
                // Анимация кнопки
                loadBtn.innerHTML = '<span>✅</span> Загружено!';
                setTimeout(() => {
                    loadBtn.innerHTML = '<span>🐾</span> Показать другую кошку';
                }, 2000);
            };
            
            newImg.onerror = () => {
                placeholder.style.display = 'block';
                imgElement.style.display = 'none';
                updateStatus('❌ Не удалось загрузить изображение', 'error');
                showNotification('Ошибка загрузки изображения', 'error');
            };
            
            newImg.src = data[0].url;
        } else {
            throw new Error('No image URL found in response');
        }
    } catch (err) {
        clearTimeout(timer);
        placeholder.style.display = 'block';
        imgElement.style.display = 'none';

        if (err.name === 'AbortError') {
            updateStatus('⏰ Время ожидания истекло. Попробуйте снова.', 'error');
            showNotification('Время загрузки истекло', 'error');
        } else {
            console.error("Проблема с fetch:", err);
            updateStatus('❌ Ошибка загрузки. Проверьте подключение к интернету.', 'error');
            showNotification('Ошибка подключения к API', 'error');
        }
    } finally {
        loadBtn.disabled = false;
    }
}

// Обработчики событий
loadBtn.addEventListener('click', loadRandomCat);

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Добавляем CSS анимации
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    // Автоматическая загрузка при открытии страницы
    setTimeout(loadRandomCat, 1000);
});

// Дополнительная функциональность: загрузка по нажатию пробела
document.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && !loadBtn.disabled) {
        e.preventDefault();
        loadRandomCat();
    }
});