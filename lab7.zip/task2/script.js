'use strict';

const loader = document.getElementById('loader');
const weatherDataContainer = document.getElementById('weatherData');
const errorContainer = document.getElementById('error');
const cityNameEl = document.getElementById('cityName');
const temperatureEl = document.getElementById('temperature');
const descriptionEl = document.getElementById('description');
const cityInput = document.getElementById('cityInput');
const getWeatherBtn = document.getElementById('getWeatherBtn');
const cookieConsentDiv = document.getElementById('cookieConsent');
const weatherIcon = document.getElementById('weatherIcon');
const windSpeedEl = document.getElementById('windSpeed');
const humidityEl = document.getElementById('humidity');
const visibilityEl = document.getElementById('visibility');
const feelsLikeEl = document.getElementById('feelsLike');

// Функция для показа уведомлений
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

function checkCookieConsent() {
    const consent = getCookie('weatherCookieConsent');
    if (consent === 'true' || consent === 'false') {
        cookieConsentDiv.style.display = 'none';
        if (consent === 'true') {
            const savedCity = getCookie('weatherCity');
            if (savedCity) {
                cityInput.value = decodeURIComponent(savedCity);
            }
        }
        return consent === 'true';
    }
    return null;
}

function setCookieConsent(consent) {
    const date = new Date();
    date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000));
    document.cookie = `weatherCookieConsent=${consent}; expires=${date.toUTCString()}; path=/`;

    if (consent) {
        saveCityToCookie(cityInput.value);
        showNotification('Настройки сохранены! 🍪', 'success');
    } else {
        removeCookie('weatherCity');
        showNotification('Cookies отключены', 'info');
    }

    cookieConsentDiv.style.display = 'none';
}

function saveCityToCookie(city) {
    const consent = getCookie('weatherCookieConsent');
    if (consent === 'true' && city.trim()) {
        const date = new Date();
        date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000));
        document.cookie = `weatherCity=${encodeURIComponent(city)}; expires=${date.toUTCString()}; path=/`;
    }
}

function removeCookie(name) {
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
}

function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split('; ');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function setWeatherIcon(description) {
    const desc = description.toLowerCase();
    if (desc.includes('sun') || desc.includes('clear')) {
        weatherIcon.textContent = '☀️';
    } else if (desc.includes('cloud') && desc.includes('sun')) {
        weatherIcon.textContent = '⛅';
    } else if (desc.includes('cloud')) {
        weatherIcon.textContent = '☁️';
    } else if (desc.includes('rain') || desc.includes('shower') || desc.includes('drizzle')) {
        weatherIcon.textContent = '🌧️';
    } else if (desc.includes('snow')) {
        weatherIcon.textContent = '❄️';
    } else if (desc.includes('storm') || desc.includes('thunder')) {
        weatherIcon.textContent = '⛈️';
    } else if (desc.includes('fog') || desc.includes('mist')) {
        weatherIcon.textContent = '🌫️';
    } else {
        weatherIcon.textContent = '🌤️';
    }
}

async function getWeather(city) {
    weatherDataContainer.style.display = 'none';
    errorContainer.style.display = 'none';
    loader.style.display = 'block';
    getWeatherBtn.disabled = true;

    const apiUrl = `https://wttr.in/${city}?format=j1`;

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error(`Не удалось получить данные для города: ${city}`);
        }
        const data = await response.json();

        const cityName = data.nearest_area[0].areaName[0].value;
        const temperature = data.current_condition[0].temp_C;
        const description = data.current_condition[0].weatherDesc[0].value;
        const windSpeed = data.current_condition[0].windspeedKmph;
        const humidity = data.current_condition[0].humidity;
        const visibility = data.current_condition[0].visibility;
        const feelsLike = data.current_condition[0].FeelsLikeC;

        cityNameEl.textContent = cityName;
        temperatureEl.textContent = temperature;
        descriptionEl.textContent = description;
        windSpeedEl.textContent = `${windSpeed} км/ч`;
        humidityEl.textContent = `${humidity}%`;
        visibilityEl.textContent = `${visibility} км`;
        feelsLikeEl.textContent = `${feelsLike}°C`;

        setWeatherIcon(description);

        weatherDataContainer.style.display = 'block';
        showNotification(`Погода в ${cityName} загружена!`, 'success');
        
        // Анимация кнопки
        getWeatherBtn.innerHTML = '<span>✅</span> Загружено!';
        setTimeout(() => {
            getWeatherBtn.innerHTML = '<span>🌤️</span> Узнать погоду';
        }, 2000);

    } catch (err) {
        errorContainer.textContent = `❌ Ошибка: ${err.message}. Попробуйте другой город.`;
        errorContainer.style.display = 'block';
        showNotification('Ошибка загрузки погоды', 'error');
    } finally {
        loader.style.display = 'none';
        getWeatherBtn.disabled = false;
    }
}

// Обработчики событий
getWeatherBtn.addEventListener('click', () => {
    const city = cityInput.value.trim();
    if (!city) {
        errorContainer.textContent = '⚠️ Пожалуйста, введите название города.';
        errorContainer.style.display = 'block';
        return;
    }
    const consent = getCookie('weatherCookieConsent');
    if (consent === 'true') {
        saveCityToCookie(city);
    }
    getWeather(city);
});

cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        getWeatherBtn.click();
    }
});

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Добавляем CSS анимации
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    const consentGiven = checkCookieConsent();
    if (consentGiven === false) {
        const savedCity = getCookie('weatherCity');
        if (savedCity) {
            removeCookie('weatherCity');
        }
    }
    
    // Автоматическая загрузка погоды для сохраненного города или Москвы
    const initialCity = cityInput.value.trim() || 'Москва';
    setTimeout(() => {
        getWeather(initialCity);
    }, 500);
});