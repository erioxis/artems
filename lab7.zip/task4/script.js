'use strict';

const HISTORY_STORAGE_KEY = 'visitHistory';
const MAX_HISTORY_LENGTH = 5;

// Функция для показа уведомлений
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

function getFormattedDateTime() {
    const now = new Date();
    return now.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

function getTimeAgo(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'только что';
    if (minutes < 60) return `${minutes} мин назад`;
    if (hours < 24) return `${hours} ч назад`;
    return `${days} дн назад`;
}

function saveVisitToHistory() {
    const history = JSON.parse(localStorage.getItem(HISTORY_STORAGE_KEY)) || [];
    const newVisit = {
        date: getFormattedDateTime(),
        timestamp: Date.now()
    };

    history.unshift(newVisit);

    if (history.length > MAX_HISTORY_LENGTH) {
        history.length = MAX_HISTORY_LENGTH;
    }

    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
    return history;
}

function updateStats(history) {
    const totalVisitsEl = document.getElementById('totalVisits');
    const lastVisitEl = document.getElementById('lastVisit');
    
    totalVisitsEl.textContent = history.length;
    
    if (history.length > 0) {
        const lastVisit = history[0];
        lastVisitEl.textContent = getTimeAgo(lastVisit.timestamp);
    } else {
        lastVisitEl.textContent = '-';
    }
}

function loadAndDisplayHistory() {
    const history = JSON.parse(localStorage.getItem(HISTORY_STORAGE_KEY)) || [];
    const historyList = document.getElementById('historyList');

    historyList.innerHTML = '';

    if (history.length === 0) {
        const noHistoryItem = document.createElement('li');
        noHistoryItem.className = 'no-history';
        noHistoryItem.innerHTML = `
            <div class="no-history-icon">📝</div>
            История посещений пуста
        `;
        historyList.appendChild(noHistoryItem);
        return history;
    }

    history.forEach((visit, index) => {
        const item = document.createElement('li');
        item.className = 'history-item';
        item.style.animationDelay = `${index * 0.1}s`;

        const dateDiv = document.createElement('div');
        dateDiv.className = 'history-date';
        dateDiv.innerHTML = `<span>📅</span> ${visit.date}`;

        const indexDiv = document.createElement('div');
        indexDiv.className = 'history-index';
        indexDiv.textContent = `#${index + 1}`;

        item.appendChild(dateDiv);
        item.appendChild(indexDiv);

        historyList.appendChild(item);
    });

    return history;
}

function clearHistory() {
    // Создаем модальное окно подтверждения
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
    `;
    
    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background: white;
        padding: 30px;
        border-radius: 12px;
        text-align: center;
        max-width: 300px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    `;
    
    modalContent.innerHTML = `
        <div style="font-size: 48px; margin-bottom: 15px;">⚠️</div>
        <h3 style="margin-bottom: 15px; color: #2c3e50;">Очистить историю?</h3>
        <p style="color: #666; margin-bottom: 20px; line-height: 1.4;">
            Вы уверены, что хотите удалить всю историю посещений? Это действие нельзя отменить.
        </p>
        <div style="display: flex; gap: 10px; justify-content: center;">
            <button id="confirmClear" style="
                background: #e74c3c;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                cursor: pointer;
                font-weight: 500;
            ">Удалить</button>
            <button id="cancelClear" style="
                background: #95a5a6;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                cursor: pointer;
                font-weight: 500;
            ">Отмена</button>
        </div>
    `;
    
    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    
    document.getElementById('confirmClear').addEventListener('click', () => {
        localStorage.removeItem(HISTORY_STORAGE_KEY);
        const history = loadAndDisplayHistory();
        updateStats(history);
        document.body.removeChild(modal);
        showNotification('История посещений очищена', 'success');
        
        // Анимация кнопки
        const clearBtn = document.getElementById('clearHistoryBtn');
        clearBtn.innerHTML = '<span>✅</span> Очищено!';
        setTimeout(() => {
            clearBtn.innerHTML = '<span>🗑️</span> Очистить историю';
        }, 2000);
    });
    
    document.getElementById('cancelClear').addEventListener('click', () => {
        document.body.removeChild(modal);
    });
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Добавляем CSS анимации
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    // Сохраняем текущее посещение
    const history = saveVisitToHistory();
    
    // Загружаем и отображаем историю
    loadAndDisplayHistory();
    updateStats(history);
    
    // Показываем уведомление о новом посещении
    if (history.length === 1) {
        showNotification('Добро пожаловать! Это ваше первое посещение.', 'success');
    } else {
        showNotification('С возвращением! Запись о посещении сохранена.', 'success');
    }

    // Обработчик кнопки очистки
    const clearBtn = document.getElementById('clearHistoryBtn');
    clearBtn.addEventListener('click', clearHistory);
});