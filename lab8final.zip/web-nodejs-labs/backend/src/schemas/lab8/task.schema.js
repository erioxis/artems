// Схема для сохранения (GET /save)
export const task1Schema = {
  type: 'object',
  properties: {
    lastname: { type: 'string', minLength: 1 },
    firstname: { type: 'string', minLength: 1 },
    surname: { type: 'string', minLength: 1 },
    gender: { type: 'string', enum: ['male', 'female'] },
    faculty: { type: 'string', minLength: 1 },
    projectParticipation: { type: 'string', enum: ['true', 'false'] },
    projectName: { type: 'string', minLength: 1 }
  },
  required: ['lastname', 'firstname', 'surname', 'gender', 'faculty', 'projectParticipation'],
  // Условие: если участвует — projectName обязателен
  if: {
    properties: { projectParticipation: { const: 'true' } }
  },
  then: {
    required: ['projectName']
  }
};

// Схема для makeInitials
export const makeInitialsSchema = {
  type: 'object',
  properties: {
    lastname: { type: 'string', minLength: 1 },
    firstname: { type: 'string', minLength: 1 },
    surname: { type: 'string', minLength: 1 }
  },
  required: ['lastname', 'firstname', 'surname']
};

// Схема для makeProjectStatus — projectName НЕ НУЖЕН!
export const makeProjectStatusSchema = {
  type: 'object',
  properties: {
    lastname: { type: 'string', minLength: 1 },
    firstname: { type: 'string', minLength: 1 },
    surname: { type: 'string', minLength: 1 },
    projectParticipation: { type: 'string', enum: ['true', 'false'] }
  },
  required: ['lastname', 'firstname', 'surname', 'projectParticipation']
};