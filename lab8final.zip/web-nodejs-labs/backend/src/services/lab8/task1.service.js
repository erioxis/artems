import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.join(__dirname, '..', '..', '..', 'data');
const dataFilePath = path.join(dataDir, 'task1.txt');

// Гарантируем существование папки data
async function ensureDataDir() {
  try {
    await fs.mkdir(dataDir, { recursive: true });
  } catch (err) {
    if (err.code !== 'EEXIST') throw err;
  }
}

class Task1Service {
  async readRecords() {
    try {
      await ensureDataDir(); // на случай, если кто-то удалил папку
      const data = await fs.readFile(dataFilePath, 'utf8');
      if (!data.trim()) {
        return []; // файл пуст — возвращаем пустой массив
      }
      return JSON.parse(data);
    } catch (error) {
      if (error.code === 'ENOENT') {
        return []; // файла нет — нормально
      }
      if (error instanceof SyntaxError && error.message.includes('Unexpected end of JSON input')) {
        console.warn('Файл task1.txt повреждён или пуст. Создаётся новый.');
        return []; // возвращаем пустой массив вместо падения
      }
      throw error; // реальные ошибки (например, доступ)
    }
  }

  async writeRecords(records) {
    await ensureDataDir();
    await fs.writeFile(dataFilePath, JSON.stringify(records, null, 2), 'utf8');
  }

  async getAll() {
    return await this.readRecords();
  }

  async makeInitials(lastname, firstname, surname) {
    return {
      lastname,
      firstnameLetter: (firstname.charAt(0) || '').toUpperCase() + '.',
      surnameLetter: (surname.charAt(0) || '').toUpperCase() + '.'
    };
  }

  async makeProjectStatus(lastname, firstname, surname, projectParticipation) {
    const initials = await this.makeInitials(lastname, firstname, surname);
    return {
      ...initials,
      projectParticipant: projectParticipation === 'true' ? 'Участвует' : 'Не участвует'
    };
  }

  async save(data) {
    const records = await this.readRecords();
    const nextId = records.length > 0 ? Math.max(...records.map(r => r.id)) + 1 : 1;

    const record = {
      id: nextId,
      lastname: data.lastname,
      firstname: data.firstname,
      surname: data.surname,
      gender: data.gender,
      faculty: data.faculty,
      projectParticipation: data.projectParticipation === 'true',
      projectName: data.projectName || null
    };

    records.push(record);
    await this.writeRecords(records);

    return record;
  }
}

export default new Task1Service();