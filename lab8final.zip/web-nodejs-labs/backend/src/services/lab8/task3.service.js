// backend/src/services/lab8/task3.service.js
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// --- Пути к файлам ---
// Внутри контейнера папка backend монтируется в /app/backend (согласно docker-compose.yml)
// Папка backend/data/task2/ будет доступна как /app/backend/data/task2/
const containerBackendDataDir = '/app/backend/data'; // Путь к проброшенной папке backend/data в контейнере
const resultsFilePath = path.join(containerBackendDataDir, 'task3', 'resultsQatar22.json');
const groupsFilePath = path.join(containerBackendDataDir, 'task2', 'groups.json'); // Читаем из /app/backend/data/task2/

console.log('--- Task3Service Paths (Inside Container - Backend/Data) ---'); // Отладка
console.log('groupsFilePath:', groupsFilePath);               // Отладка
console.log('resultsFilePath:', resultsFilePath);             // Отладка
console.log('---------------------------------------------'); // Отладка

class Task3Service {
  /**
   * Читает результаты группового этапа из groups.json (результат задания 2),
   * формирует плоский список всех матчей, сортирует по дате/времени.
   * @returns {Promise<Array>} Отсортированный список матчей.
   */
  async buildResultsFromTask2() {
    try {
      console.log('Task3Service: Попытка чтения groups.json для построения результатов...'); // Отладка
      console.log('Task3Service: Ищем файл по пути:', groupsFilePath); // Отладка
      const content = await fs.readFile(groupsFilePath, 'utf8');
      const groupsData = JSON.parse(content);

      const allMatches = [];

      // Проходим по всем группам (A, B, C, ...)
      for (const [groupName, groupData] of Object.entries(groupsData)) {
        // Проверяем, что groupData - это объект и имеет поле matches, которое является массивом
        if (groupData && typeof groupData === 'object' && Array.isArray(groupData.matches)) {
          // Проходим по матчам в поле matches
          for (const match of groupData.matches) {
            // Ожидаем, что match содержит: date, time, team1, score1, team2, score2, stadium
            // (такие поля должны были быть в groups.json после выполнения задания 2)
            allMatches.push({
              group: groupName, // Буква группы (A, B, ...)
              date: match.date, // Дата из задания 2 (в формате YYYY-MM-DD)
              time: match.time, // Время из задания 2
              team1: match.team1, // Команда 1 из задания 2
              score1: match.score1, // Счёт 1 из задания 2
              team2: match.team2, // Команда 2 из задания 2
              score2: match.score2, // Счёт 2 из задания 2
              stadium: match.stadium // Стадион из задания 2
            });
          }
        } else {
            console.warn(`Task3Service: Группа ${groupName} не содержит корректного объекта с полем matches.`, groupData); // Отладка
        }
      }

      console.log('Task3Service: Найдено матчей из groups.json:', allMatches.length); // Отладка

      // Сортируем по дате (YYYY-MM-DD) и времени
      // ВАЖНО: В вашем groups.json дата в формате YYYY-MM-DD
      allMatches.sort((a, b) => {
        // Сравниваем даты: YYYY-MM-DD
        const aDateStr = a.date; // Уже в формате YYYY-MM-DD
        const bDateStr = b.date; // Уже в формате YYYY-MM-DD

        const aDate = new Date(aDateStr);
        const bDate = new Date(bDateStr);

        if (aDate < bDate) return -1;
        if (aDate > bDate) return 1;
        // Если даты равны, сравниваем время
        if (a.time < b.time) return -1;
        if (a.time > b.time) return 1;
        return 0;
      });

      console.log('Task3Service: Матчи отсортированы.'); // Отладка
      return allMatches;
    } catch (error) {
      if (error.code === 'ENOENT') {
        console.error('Task3Service: Файл groups.json не найден по пути:', groupsFilePath); // Отладка
        console.error('Task3Service: Убедитесь, что задание 2 выполнено и файл groups.json создан в backend/data/task2/.'); // Отладка
        throw new Error('Файл groups.json не найден. Выполните задание 2 и проверьте путь внутри контейнера.');
      }
      console.error('Task3Service: Ошибка при чтении/парсинге groups.json:', error); // Отладка
      throw error;
    }
  }

  /**
   * Сохраняет отсортированный список матчей в resultsQatar22.json.
   * @param {Array} matches - Массив матчей для сохранения.
   * @returns {Promise<Array>} Сохранённый массив матчей.
   */
  async saveMatches(matches) {
    const dirPath = path.dirname(resultsFilePath);

    // Создаём папку, если её нет
    await fs.mkdir(dirPath, { recursive: true });

    await fs.writeFile(resultsFilePath, JSON.stringify(matches, null, 2), 'utf8');
    console.log('Task3Service: Файл resultsQatar22.json успешно сохранён.'); // Отладка
    return matches;
  }

  /**
   * Получает отсортированный список матчей.
   * Если resultsQatar22.json не существует, строит его из groups.json и сохраняет.
   * @returns {Promise<Array>} Отсортированный список матчей.
   */
  async getMatches() {
    try {
      console.log('Task3Service: Попытка чтения resultsQatar22.json...'); // Отладка
      console.log('Task3Service: Ищем файл по пути:', resultsFilePath); // Отладка
      const data = await fs.readFile(resultsFilePath, 'utf8');
      const parsed = JSON.parse(data);
      console.log('Task3Service: Файл resultsQatar22.json успешно прочитан, матчей:', parsed.length); // Отладка
      return parsed;
    } catch (error) {
      if (error.code === 'ENOENT') {
        console.log('Task3Service: Файл resultsQatar22.json не найден, запускаем построение из результатов задания 2...'); // Отладка
        const matches = await this.buildResultsFromTask2(); // Читаем из /app/backend/data/task2/groups.json
        return await this.saveMatches(matches); // Сохраняем в /app/backend/data/task3/resultsQatar22.json
      }
      console.error('Task3Service: Ошибка при чтении resultsQatar22.json:', error); // Отладка
      throw error;
    }
  }
}

export default new Task3Service();