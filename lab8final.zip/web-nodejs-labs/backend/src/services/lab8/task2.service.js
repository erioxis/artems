<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 2: Группы и стадионы</title>
    <style>
        body { 
            font-family: 'Tahoma', 'Arial', sans-serif; 
            margin: 0;
            padding: 0;
            background: #008080 url('back.png') center/cover no-repeat fixed;
            color: #000;
            min-height: 100vh;
            overflow-y: auto;
        }
        .desktop {
            padding: 20px;
            min-height: calc(100vh - 40px);
            position: relative;
        }
        .window {
            background-color: #ece9d8;
            border: 2px solid;
            border-top-color: #fff;
            border-left-color: #fff;
            border-right-color: #808080;
            border-bottom-color: #808080;
            padding: 3px;
            margin: 0 auto;
            width: 95%;
            max-width: 1000px;
            box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.3);
        }
        .title-bar {
            background: linear-gradient(to right, #000080, #1084d0);
            color: white;
            padding: 3px 6px;
            font-weight: bold;
            font-size: 13px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .window-content {
            padding: 20px;
            background: #ece9d8;
        }
        h1 {
            color: #000080;
            text-align: center;
            margin-top: 0;
            font-size: 16px;
            margin-bottom: 20px;
        }
        .data-section {
            margin: 20px 0;
            padding: 15px;
            background: #d4d0c8;
            border: 1px solid #808080;
        }
        .data-section h2 {
            color: #000080;
            margin-bottom: 15px;
            font-size: 14px;
            text-align: center;
            border-bottom: 1px solid #808080;
            padding-bottom: 5px;
        }
        .group-title, .stadium-title {
            font-weight: bold;
            margin: 12px 0 8px 0;
            color: #000080;
            font-size: 12px;
            border-left: 3px solid #000080;
            padding-left: 8px;
        }
        .match-item {
            padding: 6px 10px;
            margin: 5px 0;
            background: white;
            border: 1px solid #808080;
            font-size: 11px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .match-details {
            flex: 1;
            min-width: 200px;
        }
        .match-score {
            font-weight: bold;
            color: #000080;
            margin: 0 8px;
        }
        .match-stadium, .match-group {
            font-size: 10px;
            color: #666;
            font-style: italic;
        }
        .error-message {
            color: #8b0000;
            text-align: center;
            font-style: italic;
            font-size: 11px;
        }
        .button {
            background: linear-gradient(to bottom, #d4d0c8, #ece9d8);
            border: 2px solid;
            border-top-color: #fff;
            border-left-color: #fff;
            border-right-color: #808080;
            border-bottom-color: #808080;
            padding: 6px 12px;
            cursor: pointer;
            font-family: 'Tahoma';
            font-size: 11px;
            margin-bottom: 15px;
        }
        .button:hover {
            background: linear-gradient(to bottom, #eceae0, #f8f6f0);
        }
        .button:active {
            border-top-color: #808080;
            border-left-color: #808080;
            border-right-color: #fff;
            border-bottom-color: #fff;
        }
        .taskbar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(to bottom, #245edb, #1d52c1);
            height: 30px;
            display: flex;
            align-items: center;
            padding: 0 5px;
            border-top: 1px solid #fff;
        }
        .start-button {
            background: linear-gradient(to bottom, #6ca035, #3d751b);
            color: white;
            padding: 4px 10px;
            border: 1px solid;
            border-top-color: #fff;
            border-left-color: #fff;
            border-right-color: #2d4f0f;
            border-bottom-color: #2d4f0f;
            font-weight: bold;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="desktop">
        <div class="window">
            <div class="title-bar">
                <span>Задание 2: Группы и Стадионы ЧМ-2022</span>
                <span style="font-family: 'Arial'; font-size: 16px;">_ □ X</span>
            </div>
            <div class="window-content">
                <button class="button" onclick="location.href='../'">← Назад к списку заданий</button>
                
                <h1>Группы и Стадионы Чемпионата Мира 2022</h1>

                <div class="data-section">
                    <h2>Матчи по Группам</h2>
                    <div id="groupsData"></div>
                </div>

                <div class="data-section">
                    <h2>Матчи по Стадионам</h2>
                    <div id="stadiumsData"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="taskbar">
        <div class="start-button">Пуск</div>
    </div>

    <script>
        const API_URL = '/api/lab8/task2';

        async function loadGroups() {
            try {
                const res = await fetch(`${API_URL}/groups`);
                if (res.ok) {
                    const groups = await res.json();
                    const container = document.getElementById('groupsData');
                    let html = '';
                    for (const [group, groupData] of Object.entries(groups)) {
                        html += `<div class="group-section"><div class="group-title">Группа ${group}</div>`;
                        const matches = groupData.matches || groupData;
                        if (Array.isArray(matches)) {
                            matches.forEach(m => {
                                if (m.team1 && m.team2) {
                                    html += `
                                        <div class="match-item">
                                            <div class="match-details">
                                                ${m.date} ${m.time} — 
                                                <strong>${m.team1}</strong> 
                                                <span class="match-score">${m.score1} - ${m.score2}</span> 
                                                <strong>${m.team2}</strong>
                                            </div>
                                            <div class="match-stadium">
                                                (${m.stadium})
                                            </div>
                                        </div>`;
                                }
                            });
                        } else {
                             html += '<div class="error-message">Нет матчей для этой группы.</div>';
                        }
                        html += '</div>';
                    }
                    container.innerHTML = html;
                } else {
                    document.getElementById('groupsData').innerHTML = '<div class="error-message">❌ Ошибка загрузки групп</div>';
                }
            } catch (error) {
                console.error('Ошибка при загрузке групп:', error);
                document.getElementById('groupsData').innerHTML = '<div class="error-message">❌ Ошибка загрузки групп</div>';
            }
        }

        async function loadStadiums() {
            try {
                const res = await fetch(`${API_URL}/stadiums`);
                if (res.ok) {
                    const stadiums = await res.json();
                    const container = document.getElementById('stadiumsData');
                    let html = '';
                    for (const [stadium, stadiumData] of Object.entries(stadiums)) {
                        html += `<div class="stadium-section"><div class="stadium-title">${stadium}</div>`;
                        const matches = stadiumData.matches || stadiumData;
                        if (Array.isArray(matches)) {
                            matches.forEach(m => {
                                if (m.team1 && m.team2) {
                                    html += `
                                        <div class="match-item">
                                            <div class="match-details">
                                                ${m.date} ${m.time} — 
                                                <strong>${m.team1}</strong> 
                                                <span class="match-score">${m.score1} - ${m.score2}</span> 
                                                <strong>${m.team2}</strong>
                                            </div>
                                            <div class="match-group">
                                                (Группа ${m.group})
                                            </div>
                                        </div>`;
                                }
                            });
                        } else {
                             html += '<div class="error-message">Нет матчей на этом стадионе.</div>';
                        }
                        html += '</div>';
                    }
                    container.innerHTML = html;
                } else {
                    document.getElementById('stadiumsData').innerHTML = '<div class="error-message">❌ Ошибка загрузки стадионов</div>';
                }
            } catch (error) {
                console.error('Ошибка при загрузке стадионов:', error);
                document.getElementById('stadiumsData').innerHTML = '<div class="error-message">❌ Ошибка загрузки стадионов</div>';
            }
        }

        loadGroups();
        loadStadiums();
    </script>
</body>
</html>