// Файл: /src/routes/lab7/index.js
// Все обработчики - асинхронные функции

export default async function routes(fastify, options) {

  // Главный эндпоинт
  fastify.get('/', async (request, reply) => {
    return { 
      lab: '№7',
      description: 'Это главный API-эндпоинт для седьмой лабораторной.' 
    };
  });

  // Существующий task1 (можно оставить как пример)
  fastify.get('/task1', async (request, reply) => {
    await new Promise(resolve => setTimeout(resolve, 50)); // исправил на 50 мс
    return { task: 1, status: 'done', timestamp: new Date() };
  });

  // Существующий task2 (оставим, но он не используется в задании)
  fastify.get('/task2', async (request, reply) => {
    const data = [
      { id: 1, name: 'Ivan' },
      { id: 2, name: 'Maria' }
    ];
    return { task: 2, data: data };
  });

  // === ЗАДАНИЕ 1: КАЛЬКУЛЯТОР ===
  fastify.get('/calc', async (request, reply) => {
    const { operation, a, b } = request.query;

    const numA = parseFloat(a);
    const numB = parseFloat(b);

    if (isNaN(numA) || isNaN(numB)) {
      reply.code(400);
      return { error: 'Параметры "a" и "b" должны быть числами' };
    }

    if (operation === 'divide' && numB === 0) {
      reply.code(400);
      return { error: 'Деление на ноль запрещено' };
    }

    let result;
    switch (operation) {
      case 'add':
        result = numA + numB;
        break;
      case 'subtract':
        result = numA - numB;
        break;
      case 'multiply':
        result = numA * numB;
        break;
      case 'divide':
        result = numA / numB;
        break;
      default:
        reply.code(400);
        return { error: `Неизвестная операция: ${operation}. Допустимые: add, subtract, multiply, divide` };
    }

    return { operation, a: numA, b: numB, result };
  });

  // === ЗАДАНИЕ 2: ИНИЦИАЛЫ ===
  fastify.get('/task2/makeInitials', async (request, reply) => {
    const { lastname, firstname, surname } = request.query;

    if (!lastname || !firstname || !surname) {
      reply.code(400);
      return { error: 'Требуются все три поля: lastname, firstname, surname' };
    }

    const firstnameLetter = firstname.charAt(0).toUpperCase();
    const surnameLetter = surname.charAt(0).toUpperCase();

    return {
      lastname,
      firstnameLetter,
      surnameLetter
    };
  });

  // === ЗАДАНИЕ 2: СТАТУС УЧАСТИЯ В ПРОЕКТЕ ===
  fastify.get('/task2/makeProjectStatus', async (request, reply) => {
    const { lastname, firstname, surname, projectParticipant } = request.query;

    if (!lastname || !firstname || !surname) {
      reply.code(400);
      return { error: 'Требуются ФИО' };
    }

    const firstnameLetter = firstname.charAt(0).toUpperCase();
    const surnameLetter = surname.charAt(0).toUpperCase();

    // projectParticipant приходит как строка: "true" или что-то другое
    const isParticipant = projectParticipant === 'true';
    const statusText = isParticipant ? 'Участвует' : 'Не участвует';

    return {
      lastname,
      firstnameLetter,
      surnameLetter,
      projectParticipant: statusText
    };
  });

  // Пример роута с параметром (оставляем)
  fastify.get('/users/:id', async (request, reply) => {
    const { id } = request.params;
    if (id === '123') {
      return { id: id, name: 'Test User' };
    }
    reply.code(404).send({ error: 'User not found' });
  });
}