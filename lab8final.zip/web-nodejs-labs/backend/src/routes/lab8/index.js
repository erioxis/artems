import task1Service from '../../services/lab8/task1.service.js';
import { getGroups, getStadiums } from '../../services/lab8/task2.service.js'; // ✅ изменён импорт
import task3Service from '../../services/lab8/task3.service.js';
import { task1Schema, makeInitialsSchema, makeProjectStatusSchema } from '../../schemas/lab8/task.schema.js';

// Для отладки чтения cup.txt (временно)
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default async function routes(fastify, options) {
  // === ЗАДАНИЕ 1 ===
  fastify.get('/task1', async (request, reply) => {
    const records = await task1Service.getAll();
    return records;
  });

  fastify.get('/task1/makeInitials', { schema: { querystring: makeInitialsSchema } }, async (request, reply) => {
    const { lastname, firstname, surname } = request.query;
    const result = await task1Service.makeInitials(lastname, firstname, surname);
    return result;
  });

  fastify.get('/task1/makeProjectStatus', { schema: { querystring: makeProjectStatusSchema } }, async (request, reply) => {
    const { lastname, firstname, surname, projectParticipation } = request.query;
    const result = await task1Service.makeProjectStatus(lastname, firstname, surname, projectParticipation);
    return result;
  });

  fastify.get('/task1/save', { schema: { querystring: task1Schema } }, async (request, reply) => {
    const record = await task1Service.save(request.query);
    return reply.code(201).send(record);
  });

  // === ЗАДАНИЕ 2 ===
  fastify.get('/task2/groups', async (request, reply) => {
    const groups = await getGroups(); // ✅ вызов функции
    return groups;
  });

  fastify.get('/task2/stadiums', async (request, reply) => {
    const stadiums = await getStadiums(); // ✅ вызов функции
    return stadiums;
  });

  // === ОТЛАДКА: проверка cup.txt (можно удалить после проверки) ===
  fastify.get('/task2/debug-cup', async (request, reply) => {
    const cupPath = path.join(__dirname, '..', '..', '..', 'data', 'task2', 'cup.txt');
    try {
      const exists = await fs.access(cupPath).then(() => true, () => false);
      if (!exists) {
        return reply.code(404).send({ error: 'Файл cup.txt не найден', path: cupPath });
      }
      const content = await fs.readFile(cupPath, 'utf8');
      const lines = content.split('\n').slice(0, 5);
      return { exists: true, path: cupPath, firstLines: lines };
    } catch (err) {
      return reply.code(500).send({ error: err.message, path: cupPath });
    }
  });

  // === ЗАДАНИЕ 3 ===
  fastify.get('/task3/matches', async (request, reply) => {
    const matches = await task3Service.getMatches();
    return matches;
  });
}