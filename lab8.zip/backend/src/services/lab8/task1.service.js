// backend/src/services/lab8/task1.service.js
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Путь к файлу данных
const dataFilePath = path.join(__dirname, '..', '..', '..', 'data', 'lab8', 'task1', 'records.txt');
// Путь к папке данных
const dataDirPath = path.dirname(dataFilePath);

class Task1Service {
  // Создает папку, если она не существует
  async ensureDataDir() {
    try {
      await fs.mkdir(dataDirPath, { recursive: true });
    } catch (error) {
      console.error(`Ошибка при создании папки ${dataDirPath}:`, error);
      throw error; // Пробрасываем ошибку дальше
    }
  }

  // Читает данные из файла
  async readRecords() {
    try {
      const data = await fs.readFile(dataFilePath, 'utf8');
      return data.split('\n').filter(line => line.trim()).map(line => JSON.parse(line));
    } catch (error) {
      if (error.code === 'ENOENT') {
        return [];
      }
      throw error;
    }
  }

  // Записывает данные в файл
  async writeRecord(record) {
    await this.ensureDataDir(); // Убедиться, что папка существует

    const records = await this.readRecords();
    records.push(record);
    const content = records.map(r => JSON.stringify(r)).join('\n');
    await fs.writeFile(dataFilePath, content, 'utf8');
  }

  // Генерирует инициалы
  makeInitials(lastname, firstname, surname) {
    return {
      lastname,
      firstnameLetter: firstname.charAt(0).toUpperCase(),
      surnameLetter: surname.charAt(0).toUpperCase()
    };
  }

  // Генерирует статус участия в проекте
  makeProjectStatus(lastname, firstname, surname, projectParticipation) {
    const initials = this.makeInitials(lastname, firstname, surname);
    return {
      ...initials,
      projectParticipant: projectParticipation ? 'Участвует' : 'Не участвует'
    };
  }

  // Публичные методы для роутов
  async getInitials(lastname, firstname, surname) {
    return this.makeInitials(lastname, firstname, surname);
  }

  async getProjectStatus(lastname, firstname, surname, projectParticipation) {
    return this.makeProjectStatus(lastname, firstname, surname, projectParticipation);
  }

  async savePerson(personData) {
    // Генерируем ID
    const records = await this.readRecords();
    const nextId = records.length > 0 ? Math.max(...records.map(r => r.id)) + 1 : 1;

    // Создаем запись
    const record = {
      id: nextId,
      ...personData,
      createdAt: new Date().toISOString()
    };

    // Сохраняем
    await this.writeRecord(record);

    return record;
  }

  async getAllRecords() {
    return await this.readRecords();
  }
}

export default new Task1Service();