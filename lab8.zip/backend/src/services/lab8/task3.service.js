// backend/src/services/lab8/task3.service.js
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ИСПРАВЛЕННЫЕ ПУТИ (убрано избыточное 'backend')
const sourceFilePath = path.join(__dirname, '..', '..', '..', 'data', 'lab8', 'task2', 'cup.txt');
const resultsOutputPath = path.join(__dirname, '..', '..', '..', 'data', 'lab8', 'task3', 'resultsQatar22.json');
const dataDirPath = path.dirname(resultsOutputPath);

class Task3Service {
  async ensureDataDir() {
    try {
      await fs.mkdir(dataDirPath, { recursive: true });
      console.log(`Папка данных создана: ${dataDirPath}`);
    } catch (error) {
      console.error(`Ошибка при создании папки ${dataDirPath}:`, error);
      throw error;
    }
  }

  async loadSourceFile() {
    try {
      console.log(`Чтение файла: ${sourceFilePath}`);
      const data = await fs.readFile(sourceFilePath, 'utf8');
      console.log(`Файл успешно прочитан, размер: ${data.length}`);
      return data;
    } catch (error) {
      console.error(`Ошибка при чтении файла ${sourceFilePath}:`, error);
      if (error.code === 'ENOENT') {
        throw new Error(`Исходный файл ${sourceFilePath} не найден. Убедитесь, что он загружен.`);
      }
      throw error;
    }
  }

  parseCupData(text) {
    console.log('Начинаем парсинг данных...');
    
    const lines = text.split('\n');
    const matches = [];
    let currentGroup = null;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      // Пропускаем пустые строки
      if (!line) continue;
      
      // Определяем текущую группу по строкам вида "Group A"
      if (line.startsWith('Group') && line.length === 7) {
        currentGroup = line.charAt(6); // Берем букву после "Group "
        console.log(`Обнаружена группа: ${currentGroup}`);
        continue;
      }
      
      // Ищем матчи в формате "(номер) День Месяц/День ГГГГ ЧЧ:ММ      Команда1   счет (счет в перерыве)   Команда2   @ Стадион, Город"
      // Пример: "(1) Sun Nov/20 19:00      Qatar   0-2 (0-2)   Ecuador    @ Al Bayt Stadium, Al Khor"
      const matchRegex = /^\((\d+)\)\s+(\w+)\s+(\w+\/\d{1,2})\s+(\d{2}:\d{2})\s+([A-Za-z\s]+?)\s+(\d+-\d+)\s+\((\d+-\d+)\)\s+([A-Za-z\s]+?)\s+@\s+([A-Za-z\s,]+)/;
      const matchLine = matchRegex.exec(line);
      
      if (matchLine) {
        const matchNumber = matchLine[1];
        const dayOfWeek = matchLine[2];
        const dateInfo = matchLine[3]; // Например, "Nov/20"
        const time = matchLine[4]; // Например, "19:00"
        const team1 = matchLine[5].trim();
        const fullScore = matchLine[6]; // Например, "0-2"
        const halfTimeScore = matchLine[7]; // Например, "0-2"
        const team2 = matchLine[8].trim();
        const stadiumInfo = matchLine[9].trim();
        
        // Разделяем дату на месяц и день
        const [month, day] = dateInfo.split('/');
        const formattedDate = `${day.padStart(2, '0')}.${month.padStart(3, '0')}.2022`;
        
        // Извлекаем название стадиона и город
        const stadiumParts = stadiumInfo.split(',');
        const stadiumName = stadiumParts[0].trim();
        const city = stadiumParts[1] ? stadiumParts[1].trim() : '';
        
        const match = {
          group: currentGroup,
          date: formattedDate,
          time,
          team1,
          score: fullScore,
          team2,
          stadium: stadiumName,
          city,
          matchNumber
        };
        
        console.log(`Добавлен матч: ${match.group} ${match.date} ${match.team1} vs ${match.team2}`);
        matches.push(match);
      }
    }
    
    console.log(`Парсинг завершен. Всего найдено матчей: ${matches.length}`);
    return matches;
  }

  async saveToFile(filePath, data) {
    await this.ensureDataDir();
    console.log(`Сохранение данных в файл: ${filePath}`);
    try {
      await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf8');
      console.log(`Данные успешно сохранены в ${filePath}`);
    } catch (error) {
      console.error(`Ошибка при записи в файл ${filePath}:`, error);
      throw error;
    }
  }

  async generateResults() {
    try {
      console.log('=== НАЧАЛО ГЕНЕРАЦИИ РЕЗУЛЬТАТОВ ===');
      const text = await this.loadSourceFile();
      const matches = this.parseCupData(text);
      
      if (matches.length === 0) {
        console.error('Не удалось найти ни одного матча в файле!');
        throw new Error('Парсинг не обнаружил матчей в файле cup.txt. Проверьте формат файла.');
      }
      
      // Сортируем матчи по дате и времени в хронологическом порядке
      matches.sort((a, b) => {
        const [dayA, monthA, yearA] = a.date.split('.');
        const [dayB, monthB, yearB] = b.date.split('.');
        const dateA = new Date(`${yearA}-${monthA}-${dayA}T${a.time}`);
        const dateB = new Date(`${yearB}-${monthB}-${dayB}T${b.time}`);
        return dateA - dateB;
      });
      
      await this.saveToFile(resultsOutputPath, matches);
      
      console.log('=== ГЕНЕРАЦИЯ РЕЗУЛЬТАТОВ ЗАВЕРШЕНА ===');
      return matches;
    } catch (err) {
      console.error('КРИТИЧЕСКАЯ ОШИБКА ПРИ ГЕНЕРАЦИИ РЕЗУЛЬТАТОВ:', err);
      throw err;
    }
  }

  async getResults() {
    try {
      console.log(`Загрузка результатов из файла: ${resultsOutputPath}`);
      const data = await fs.readFile(resultsOutputPath, 'utf8');
      const results = JSON.parse(data);
      console.log(`Загружено результатов: ${results.length}`);
      return results;
    } catch (error) {
      console.error(`Ошибка при чтении файла результатов:`, error);
      if (error.code === 'ENOENT') {
        return [];
      }
      throw error;
    }
  }
}

export default new Task3Service();