// backend/src/schemas/lab8/task1.schema.js
export const createPersonBodySchema = {
  type: 'object',
  properties: {
    lastname: { type: 'string', minLength: 1 },
    firstname: { type: 'string', minLength: 1 },
    surname: { type: 'string', minLength: 1 },
    gender: { type: 'string', enum: ['male', 'female'] },
    faculty: { type: 'string', minLength: 1 },
    projectParticipation: { type: 'boolean' },
    projectName: { type: 'string', nullable: true } // Может быть null, если участия нет
  },
  required: ['lastname', 'firstname', 'surname', 'gender', 'faculty', 'projectParticipation'],
  // Условная валидация: если projectParticipation === true, то projectName обязательное поле
  if: { properties: { projectParticipation: { const: true } } },
  then: { required: ['projectName'] },
  else: { properties: { projectName: { type: 'null' } } }
};