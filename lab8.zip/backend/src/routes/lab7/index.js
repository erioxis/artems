// Файл: /src/routes/lab7/index.js
// Все обработчики - асинхронные функции
export default async function routes(fastify, options) {
    // Доступен по GET /api/lab7/
    fastify.get('/', async (request, reply) => {
        return {
            lab: '№7',
            description: 'Это главный API-эндпоинт для седьмой лабораторной.'
        };
    });

    // --- Задание 1: Калькулятор ---
    // Доступен по GET /api/lab7/task1
    // Пример: /api/lab7/task1?operation=add&a=5&b=3
    fastify.get('/task1', async (request, reply) => {
        const { operation, a, b } = request.query;

        if (operation === undefined || a === undefined || b === undefined) {
            reply.code(400).send({ error: 'Missing required query parameters: operation, a, b' });
            return;
        }

        const op = operation.toLowerCase();
        const numA = parseFloat(a);
        const numB = parseFloat(b);

        if (isNaN(numA) || isNaN(numB)) {
            reply.code(400).send({ error: 'Parameters a and b must be numbers' });
            return;
        }

        let result;
        switch (op) {
            case 'add':
                result = numA + numB;
                break;
            case 'subtract':
                result = numA - numB;
                break;
            case 'multiply':
                result = numA * numB;
                break;
            case 'divide':
                if (numB === 0) {
                    reply.code(400).send({ error: 'Cannot divide by zero' });
                    return;
                }
                result = numA / numB;
                break;
            default:
                reply.code(400).send({ error: 'Invalid operation. Supported: add, subtract, multiply, divide' });
                return;
        }

        return { operation: op, a: numA, b: numB, result: result };
    });
    // --- Конец Задания 1 ---

    // --- Задание 2: API эндпоинты ---
    // Доступен по GET /api/lab7/task2/makeInitials
    // Пример: /api/lab7/task2/makeInitials?fullname=Иванов+Иван+Иванович
    fastify.get('/task2/makeInitials', async (request, reply) => {
        const { fullname } = request.query;

        if (!fullname) {
            reply.code(400).send({ error: 'Missing required query parameter: fullname' });
            return;
        }

        const parts = fullname.trim().split(/\s+/);
        if (parts.length < 3) {
            reply.code(400).send({ error: 'Fullname must contain at least 3 parts: lastname firstname surname' });
            return;
        }

        const [lastname, firstname, surname] = parts;
        const initials = {
            lastname: lastname,
            firstnameLetter: firstname.charAt(0).toUpperCase() + '.',
            surnameLetter: surname.charAt(0).toUpperCase() + '.'
        };

        return initials;
    });

    // Доступен по GET /api/lab7/task2/makeProjectStatus
    // Пример: /api/lab7/task2/makeProjectStatus?fullname=Иванов+Иван+Иванович&projectParticipation=true
    fastify.get('/task2/makeProjectStatus', async (request, reply) => {
        const { fullname, projectParticipation } = request.query;

        if (!fullname) {
            reply.code(400).send({ error: 'Missing required query parameter: fullname' });
            return;
        }

        const parts = fullname.trim().split(/\s+/);
        if (parts.length < 3) {
            reply.code(400).send({ error: 'Fullname must contain at least 3 parts: lastname firstname surname' });
            return;
        }

        const [lastname, firstname, surname] = parts;
        const participation = projectParticipation === 'true'; // Преобразуем строку в булево

        const status = {
            lastname: lastname,
            firstnameLetter: firstname.charAt(0).toUpperCase() + '.',
            surnameLetter: surname.charAt(0).toUpperCase() + '.',
            projectParticipant: participation ? 'Участвует' : 'Не участвует'
        };

        return status;
    });
}