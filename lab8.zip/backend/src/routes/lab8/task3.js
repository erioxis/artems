// backend/src/routes/lab8/task3.js
import task3Service from '../../services/lab8/task3.service.js';

export default async function routes(fastify, options) {
  // POST /api/lab8/task3/generate (генерация итогового JSON)
  fastify.post('/generate', async (request, reply) => {
    try {
      const results = await task3Service.generateResults();
      return { message: 'JSON с результатами успешно сгенерирован.', count: results.length };
    } catch (err) {
      return reply.status(500).send({ error: err.message });
    }
  });

  // GET /api/lab8/task3/results (получение итоговых результатов)
  fastify.get('/results', async (request, reply) => {
    const results = await task3Service.getResults();
    return results;
  });
}