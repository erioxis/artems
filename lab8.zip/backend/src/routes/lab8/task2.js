// backend/src/routes/lab8/task2.js

import task2Service from '../../services/lab8/task2.service.js';

export default async function routes(fastify, options) {
  // POST /api/lab8/task2/process (запуск обработки)
  fastify.post('/process', async (request, reply) => {
    console.log("=== ВЫЗОВ РОУТА POST /api/lab8/task2/process ==="); // Лог
    try {
      const result = await task2Service.processAndSave();
      console.log("=== РОУТ POST /api/lab8/task2/process УСПЕШНО ЗАВЕРШЕН ==="); // Лог
      return { message: 'Обработка завершена успешно.', result };
    } catch (err) {
      console.error('Ошибка в task2.process:', err); // Лог
      return reply.status(500).send({ error: err.message });
    }
  });

  // GET /api/lab8/task2/groups (получение данных по группам)
  fastify.get('/groups', async (request, reply) => {
    console.log("=== ВЫЗОВ РОУТА GET /api/lab8/task2/groups ==="); // Лог
    try {
      const groups = await task2Service.getGroups();
      if (Object.keys(groups).length === 0) {
        console.log("getGroups: возвращаем 404"); // Лог
        return reply.status(404).send({ error: 'Данные по группам не найдены. Сначала обработайте файл.' });
      }
      console.log("getGroups: возвращаем данные"); // Лог
      return groups;
    } catch (err) {
      console.error('Ошибка в task2.getGroups:', err); // Лог
      return reply.status(500).send({ error: err.message });
    }
  });

  // GET /api/lab8/task2/stadiums (получение данных по стадионам)
  fastify.get('/stadiums', async (request, reply) => {
    console.log("=== ВЫЗОВ РОУТА GET /api/lab8/task2/stadiums ==="); // Лог
    try {
      const stadiums = await task2Service.getStadiums();
      if (Object.keys(stadiums).length === 0) {
        console.log("getStadiums: возвращаем 404"); // Лог
        return reply.status(404).send({ error: 'Данные по стадионам не найдены. Сначала обработайте файл.' });
      }
      console.log("getStadiums: возвращаем данные"); // Лог
      return stadiums;
    } catch (err) {
      console.error('Ошибка в task2.getStadiums:', err); // Лог
      return reply.status(500).send({ error: err.message });
    }
  });
}