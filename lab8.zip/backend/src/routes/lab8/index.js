// backend/src/routes/lab8/index.js
import task1Routes from './task1.js';
import task2Routes from './task2.js';
import task3Routes from './task3.js';

export default async function routes(fastify, options) {
  // Регистрируем роуты для Задания 1
  fastify.register(task1Routes, { prefix: '/task1' });

  // Регистрируем роуты для Задания 2
  fastify.register(task2Routes, { prefix: '/task2' });

  // Регистрируем роуты для Задания 3
  fastify.register(task3Routes, { prefix: '/task3' });
}