// backend/src/routes/lab8/task1.js
import task1Service from '../../services/lab8/task1.service.js';
import { createPersonBodySchema } from '../../schemas/lab8/task1.schema.js';

export default async function routes(fastify, options) {
  // GET /api/lab8/task1/makeInitials
  fastify.get('/makeInitials', async (request, reply) => {
    const { lastname, firstname, surname } = request.query;
    if (!lastname || !firstname || !surname) {
      return reply.status(400).send({ error: 'Пожалуйста, укажите lastname, firstname и surname.' });
    }
    return task1Service.getInitials(lastname, firstname, surname);
  });

  // GET /api/lab8/task1/makeProjectStatus
  fastify.get('/makeProjectStatus', async (request, reply) => {
    const { lastname, firstname, surname, projectParticipation } = request.query;
    if (!lastname || !firstname || !surname || projectParticipation === undefined) {
      return reply.status(400).send({ error: 'Пожалуйста, укажите все необходимые параметры.' });
    }
    const boolParticipation = projectParticipation === 'true' || projectParticipation === true;
    return task1Service.getProjectStatus(lastname, firstname, surname, boolParticipation);
  });

  // POST /api/lab8/task1/savePerson (для формы)
  fastify.post('/savePerson', {
    schema: {
      body: createPersonBodySchema
    }
  }, async (request, reply) => {
    const savedPerson = await task1Service.savePerson(request.body);
    return reply.code(201).send(savedPerson);
  });

  // GET /api/lab8/task1/records (для индексной страницы)
  fastify.get('/records', async (request, reply) => {
    const records = await task1Service.getAllRecords();
    return records;
  });
}