function performCalculation() {
            const a = document.getElementById('a').value;
            const b = document.getElementById('b').value;
            const operation = document.getElementById('operation').value;

            const url = `/api/lab7/task1?operation=${encodeURIComponent(operation)}&a=${encodeURIComponent(a)}&b=${encodeURIComponent(b)}`;

            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        return response.json().then(err => { throw new Error(err.error || 'Network response was not ok'); });
                    }
                    return response.json();
                })
                .then(data => {
                    const resultDiv = document.getElementById('calcResult');
                    resultDiv.innerText = `Результат: ${data.result}`;
                    resultDiv.style.display = 'block'; // Показываем результат
                })
                .catch(error => {
                    console.error('Error calculating:', error);
                    const resultDiv = document.getElementById('calcResult');
                    resultDiv.innerText = `Ошибка: ${error.message}`;
                    resultDiv.style.display = 'block';
                });
        }